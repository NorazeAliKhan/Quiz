---
name: Obsidian Cybernetic
colors:
  surface: '#131319'
  surface-dim: '#131319'
  surface-bright: '#39383f'
  surface-container-lowest: '#0e0e13'
  surface-container-low: '#1b1b21'
  surface-container: '#1f1f25'
  surface-container-high: '#2a2930'
  surface-container-highest: '#34343b'
  on-surface: '#e4e1ea'
  on-surface-variant: '#c9c4d8'
  inverse-surface: '#e4e1ea'
  inverse-on-surface: '#303036'
  outline: '#938ea1'
  outline-variant: '#484555'
  surface-tint: '#cabeff'
  primary: '#cabeff'
  on-primary: '#31009a'
  primary-container: '#947dff'
  on-primary-container: '#2a0088'
  inverse-primary: '#603ce2'
  secondary: '#42e1e1'
  on-secondary: '#003737'
  secondary-container: '#00c4c4'
  on-secondary-container: '#004c4c'
  tertiary: '#cebdff'
  on-tertiary: '#381385'
  tertiary-container: '#9b7fed'
  on-tertiary-container: '#31057e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e6deff'
  primary-fixed-dim: '#cabeff'
  on-primary-fixed: '#1c0062'
  on-primary-fixed-variant: '#4816cb'
  secondary-fixed: '#61f8f8'
  secondary-fixed-dim: '#3adbdb'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f50'
  tertiary-fixed: '#e8ddff'
  tertiary-fixed-dim: '#cebdff'
  on-tertiary-fixed: '#21005e'
  on-tertiary-fixed-variant: '#4f319c'
  background: '#131319'
  on-background: '#e4e1ea'
  surface-variant: '#34343b'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-spec:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels the refined precision, tactical tactility, and obsessive craft of bespoke enthusiast keyboards. It merges ultra-dark industrial minimalism with a calibrated cybernetic glow. The visual language is engineered for developers, competitive esports athletes, and mechanical keyboard artisans who demand both utilitarian clarity and bespoke visual prestige.

The style unites deep, multi-tiered charcoal surfaces with razor-sharp micro-borders, punctuated by electric violet and photonic cyan accents reminiscent of sub-switch PCB illumination and anodized aluminum chamfers. Every element evokes physical industrial design: anodized switch plates, CNC-machined cases, PBT dye-sub keycaps, and linear actuation curves. Translucency is applied with restraint to simulate smoky polycarbonate diffusers rather than frivolous decorative glass. The interface feels weightless yet grounded, high-performance, and ruthlessly clean.

## Colors

The palette is anchored in an uncompromising deep dark mode. It establishes depth without muddiness through stepped cool-charcoal layers rather than pure monochromatic blacks.

- **Background & Base**:
  - Deepest Canvas (Body Base): `#0D0D12`
  - Default Container / Section Backing: `#14141A`
  - Layered Surface Tier 1: `#1C1C24`
  - Layered Surface Tier 2 / Interactive Hover Backing: `#242430`

- **Surfaces & Cards**:
  - Rest Surface: `#1A1A24`
  - Elevated / Interactive Surface: `#22222E`
  - Structural Borders & Plate Dividers: `#2F2F3E`
  - Focused / Highlighted Border: `#3F3F56`

- **Typography & Foreground**:
  - Primary Readout / High-Emphasis: `#F4F4F6` (Soft white to eliminate retina fatigue)
  - Secondary Readout / Labels / Subtitles: `#9E9EB8` (Muted cool gray)
  - De-emphasized / Hotkeys / Inactive: `#65657E`

- **Accents & Illumination**:
  - Primary Accent (Actuation / Electric Violet): `#7C5CFF`
  - Primary Ambient Glow: `rgba(124, 92, 255, 0.28)`
  - Secondary Accent (Telemetry / Electric Cyan): `#2DD4D4`
  - Secondary Ambient Glow: `rgba(45, 212, 212, 0.24)`
  - Tertiary / Switch State / Modifiers: `#A78BFA`

Use electric cyan strictly for precise feedback, actuation status, latency metrics, and interactive triggers. Reserve electric violet for primary navigational weight, primary actions, and brand elevation.

## Typography

The typographic hierarchy establishes clear structural rhythm by combining three dedicated type families:

1. **Space Grotesk (Headlines & Metrics)**: Delivers a clean, structural aesthetic with subtle mechanical quirks that mirror keycap legends and industrial tooling. Headings must always maintain tight negative letter-spacing to feel compact and high-tensile.
2. **Inter (Body & UI Controls)**: Provides crystal-clear legibility at all scale points across high-density hardware configurators, switch travel curves, and narrative copy.
3. **JetBrains Mono (Technical Specifications & Keycode Labels)**: Injected for keyboard shortcuts, polling rates (e.g., `8000Hz`), actuation distance readings (`1.2mm`), and firmware parameters.

All typographic sizes above 32px downscale automatically on mobile viewports to prevent unwanted line wrapping in compact matrix layouts.

## Layout & Spacing

The layout is built on a modular 12-column fluid grid system pinned to an 8px base rhythm. Content maxes out at a standard 1440px desktop frame to ensure optimal ergonomic scanning angles.

- **Desktop (1024px and above)**: 12-column architecture, 48px canvas margins, 24px column gutters. High-density configurator modules may nest internal 6-column sub-grids.
- **Tablet (768px - 1023px)**: 8-column architecture, 32px canvas margins, 20px column gutters. Secondary inspector sidebars collapse into slide-over sheets.
- **Mobile (Below 768px)**: 4-column architecture, 20px margins, 16px column gutters. Key visualizers and interactive keyboard switch matrices convert to horizontally scrollable viewports with tactile snap-points.

Horizontal and vertical rhythm follows strict proportional intervals: `space-xs` (4px) for tight badge padding and chip gaps; `space-sm` (8px) for icon-to-label bindings; `space-md` (16px) for interior card padding and input field internal spacing; `space-lg` (24px) for stacked panel sections; and `space-xl` (40px) for separating major layout groups.

## Elevation & Depth

This design system avoids generic drop shadows, relying instead on tonal layering, precise dark-slate borders, and atmospheric chromatic diffusion.

- **Layer Tier 0 (Canvas Base)**: `#0D0D12`. Serves as the substrate layer.
- **Layer Tier 1 (Docked Containers & Background Trays)**: `#14141A` bordered by a 1px solid stroke of `#1C1C24`.
- **Layer Tier 2 (Interactive Modules, Key Cards, Configurator Panes)**: `#1A1A24` bordered by a 1px solid stroke of `#2F2F3E`. Elevated subtly through a deep ambient shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.65)`.
- **Layer Tier 3 (Floating Modals, Switch Flyouts, Dropdowns)**: `#22222E` with a 1px perimeter of `#3F3F56` and an ambient shadow: `0 16px 36px -6px rgba(0, 0, 0, 0.85)`.

**Luminescent Glow System**:
Elements in active, pressed, or actuated states receive an inner specular reflection combined with an outer photon bloom:
- **Violet Actuation**: `box-shadow: 0 0 0 1px #7C5CFF, 0 0 20px -2px rgba(124, 92, 255, 0.35);`
- **Cyan Signal / Status**: `box-shadow: 0 0 0 1px #2DD4D4, 0 0 20px -2px rgba(45, 212, 212, 0.30);`
- **Polycarbonate Smoked Overlays**: `background: rgba(26, 26, 36, 0.72); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.08);`

## Shapes

The shape vocabulary takes direct inspiration from modern mechanical keycaps (such as Cherry, OEM, and MT3 profiles) and CNC aluminum chassis edges: smooth, sculpted corners balanced by firm linear silhouettes.

- **Standard Elements (Buttons, Inputs, Selectors)**: `rounded` (0.5rem / 8px).
- **Cards, Key Switch Panels, and Modules**: `rounded-lg` (1rem / 16px).
- **Feature Banners, Hero Configurator Stages, Large Modals**: `rounded-xl` (1.5rem / 24px).
- **Keycap Badges & Micro Status Pills**: Fully rounded pill shapes (`border-radius: 9999px`) to visually contrast against structured rectangular component blocks.

## Components

### Buttons
- **Primary Action (Actuation Violet)**:
  - Background: Linear gradient from `#7C5CFF` to `#6846F9`. Text: `#FFFFFF`.
  - Border: 1px solid rgba(255, 255, 255, 0.16). Radius: `rounded` (8px). Height: 44px. Font: `label-lg`.
  - Hover: Background `#8C6FFF`; Box Shadow: `0 0 24px -2px rgba(124, 92, 255, 0.45)`.
  - Active: Scale down to 98% with instantaneous mechanical snappiness.
- **Secondary (Machined Slate)**:
  - Background: `#1A1A24`. Border: 1px solid `#2F2F3E`. Text: `#F4F4F6`.
  - Hover: Border color shifts to `#3F3F56`, background shifts to `#22222E`.
- **Tertiary / Ghost (Keycap Tool)**:
  - Background: Transparent. Text: `#9E9EB8`.
  - Hover: Text becomes `#F4F4F6`, background `rgba(124, 92, 255, 0.08)`.

### Cards & Chassis Panels
- **Standard Card**:
  - Background: `#1A1A24`. Border: 1px solid `#2F2F3E`. Corner Radius: `rounded-lg` (16px). Padding: `space-lg` (24px).
  - Hover (Interactive Card): Top border transitions to a subtle gradient stroke (`#7C5CFF` to `#2DD4D4`), shadow adds `0 8px 30px rgba(0, 0, 0, 0.5)`.
- **Acoustic / Spec Showcase Card**:
  - Contains an integrated JetBrains Mono spec chip at the top right, with dark linear separators (`#242430`) isolating individual technical rows.

### Chips & Badges
- **Specification Chips**:
  - Background: `#14141A`. Border: 1px solid `#242430`. Border radius: 9999px. Padding: 4px 10px. Typography: `code-spec`. Color: `#9E9EB8`.
- **Live Status Chip (e.g., Latency, Wireless Mode)**:
  - Background: `rgba(45, 212, 212, 0.08)`. Border: 1px solid `rgba(45, 212, 212, 0.28)`. Text: `#2DD4D4`. Includes a 6px glowing `#2DD4D4` dot on the leading edge.

### Input Fields & Controls
- **Text & Numeric Inputs**:
  - Background: `#14141A`. Border: 1px solid `#2F2F3E`. Corner radius: `rounded` (8px). Height: 44px. Text: `#F4F4F6`. Placeholder: `#65657E`.
  - Focus: Border: 1px solid `#7C5CFF`. Glow: `0 0 0 2px rgba(124, 92, 255, 0.20)`.
- **Checkboxes & Radios**:
  - Base: 18x18px, `#14141A` fill, `#2F2F3E` stroke. Corner radius: 4px for checkboxes, 50% for radios.
  - Checked State: `#7C5CFF` fill with a crisp `#F4F4F6` check icon or inner dot, surrounded by an ambient violet halo.

### Specialized Hardware Components
- **Interactive Switch Profile Slider**:
  - Track: 4px height, `#242430` background with filled gradient (`#7C5CFF` to `#2DD4D4`) tracking actuation depth.
  - Thumb: 18px cylindrical pill inspired by cross-stem mechanical switches, filled with `#FFFFFF` and glowing cyan on touch.
- **Key Matrix Map Cell (Layout Configurator)**:
  - Aspect ratio: 1:1 (single key unit). Base: `#1C1C24` fill, `#2F2F3E` border. Radius: 6px.
  - Text: Top-left legend in `Space Grotesk` (12px, `#F4F4F6`), sub-legend in `JetBrains Mono` (10px, `#65657E`).
  - Active / Key Pressed State: `#7C5CFF` background, text in pure `#FFFFFF`, instant zero-duration transform scale(0.95).